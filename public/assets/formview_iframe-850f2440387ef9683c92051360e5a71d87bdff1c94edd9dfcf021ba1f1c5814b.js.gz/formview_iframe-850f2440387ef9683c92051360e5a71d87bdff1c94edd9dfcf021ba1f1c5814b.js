(function() {
  jQuery(function() {
    return $('#formview_iframe').iFrameResize();
  });

}).call(this);
