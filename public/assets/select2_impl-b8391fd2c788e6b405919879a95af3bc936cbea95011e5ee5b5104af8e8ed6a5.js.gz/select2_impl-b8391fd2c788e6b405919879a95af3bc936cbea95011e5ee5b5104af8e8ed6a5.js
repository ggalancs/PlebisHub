jQuery(function($) {
    $('select').select2({
        formatNoMatches: "No se encontraron resultados"
    });
});
