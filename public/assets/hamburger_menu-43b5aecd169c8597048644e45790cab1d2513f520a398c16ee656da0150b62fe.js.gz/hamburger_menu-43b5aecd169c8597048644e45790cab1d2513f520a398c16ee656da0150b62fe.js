jQuery(function($) {
    $('#hamburger_menu').sidr({
        name: 'sidr-right',
        side: 'right',
        source: '#sidr-menu'
    });
});

